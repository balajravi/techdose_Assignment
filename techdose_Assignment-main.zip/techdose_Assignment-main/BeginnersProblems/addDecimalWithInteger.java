import java.util.*;
class Main{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        double num1=sc.nextDoauble();
        int num2=sc.nextInt();
        System.out.println(num1+num2);
    }
}
