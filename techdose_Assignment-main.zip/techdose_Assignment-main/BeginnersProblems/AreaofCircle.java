//Find area of a circle given radius as integer
import java.util.*;

public class Main {
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        int R=sc.nextInt();
        System.out.printf("%.2f",(2*(22.0/7.0)*R));
    }
}
