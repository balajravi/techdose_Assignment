class Solution {
    public int[] numberOfPairs(int[] nums) {
        HashMap<Integer,Integer> map = new HashMap<>();
        int n = nums.length;
        int count = 0;
        
        for(int i=0 ; i<n ; i++){
            map.put(nums[i] , map.getOrDefault(nums[i] , 0)+1);
            
            if(map.get(nums[i]) == 2){
                map.remove(nums[i]);
                count++;
            }
        }
        return new int[]{count,map.size()};
    }
}
