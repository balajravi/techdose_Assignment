class Solution {
    public int maximumXOR(int[] nums) {
        int res=0;a
        for(int a:nums)
            res= res|a;
        return res;
    }
}
