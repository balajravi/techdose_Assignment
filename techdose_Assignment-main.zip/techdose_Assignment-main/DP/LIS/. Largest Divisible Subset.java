class Solution {
    public List<Integer> largestDivisibleSubset(int[] nums) {
        Arrays.sort(nums);
        int[] lis = new int[nums.length];
        Arrays.fill(lis,1);
        int[] hash = new int[nums.length];
        List<Integer> list = new ArrayList<>();
        int result=1;
        int lastIndex=0;
        for(int i=0;i<nums.length;i++){
            hash[i]=i;
            for(int j=0;j<i;j++){
                if(nums[i]%nums[j]==0 && lis[i]<=lis[j]){
                    lis[i]=lis[j]+1;
                    hash[i]=j;
                }
                if(lis[i]>result){
                    result=lis[i];
                    lastIndex=i;
                }
            }
        }
        list.add(nums[lastIndex]);
        while(hash[lastIndex]!=lastIndex){
            lastIndex=hash[lastIndex];
            list.add(nums[lastIndex]);
        }
        Collections.sort(list);
        return list;
    }
}/*
Given a set of distinct positive integers nums, return the largest subset answer such that every pair (answer[i], answer[j]) of elements in this subset satisfies:

answer[i] % answer[j] == 0, or
answer[j] % answer[i] == 0
If there are multiple solutions, return any of them.

 

Example 1:

Input: nums = [1,2,3]
Output: [1,2]
Explanation: [1,3] is also accepted.
Example 2:

Input: nums = [1,2,4,8]
Output: [1,2,4,8]
*/
